# autoTileKwinScript 
Automatic tiles windows created almost tiled

When a window was tiled to left or right and you close it, the next time you'll open it, if it will remember its position, it will be *almost* in the same position, but it won't be tiled, meaning that clicking on the left or right corner of your screen (depending on where your close buttons are) won't click the button

so this script just automatically tiles it in this case, nothing more, nothing less

## installation
```shell
git clone https://github.com/tubbadu/autoTileKwinScript
cd autoTileKwinScript
plasmapkg2 --install .
```